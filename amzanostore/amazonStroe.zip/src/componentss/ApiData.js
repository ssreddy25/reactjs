import React, { useState } from 'react'

function ApiData() {
    const[product,setProduct]=useState([])
  return (
    <div>
      
    </div>
  )
}

export default ApiData
