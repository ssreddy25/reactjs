import React from 'react'

const Edit = () => {
  return (
    <div>
      <h1>edit functionalty</h1>
    </div>
  )
}

export default Edit
